from django.db import models
from django.core.validators import FileExtensionValidator

def file_size(value): # add this to some file where you can import it from
    limit = 2 * 1024 * 1024
    print("value ", value)
    if value.size > limit:
        raise ValidationError('File too large. Size should not exceed 2 MiB.')
# Create your models here.

class Book(models.Model):
    HARDCOVER = 1
    PAPERBACK = 2
    EBOOK = 3
    BOOK_TYPES = (
        (HARDCOVER, 'Hardcover'),
        (PAPERBACK, 'Paperback'),
        (EBOOK, 'E-book'),
    )
    title = models.CharField(max_length=50)
    publication_date = models.DateField(blank=True, null=True)
    author = models.CharField(max_length=30, blank=True)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    pages = models.IntegerField(blank=True, null=True)
    book_type = models.PositiveSmallIntegerField(choices=BOOK_TYPES, blank=True, null=True)
    book_image = models.FileField(upload_to='books/', validators=[file_size])